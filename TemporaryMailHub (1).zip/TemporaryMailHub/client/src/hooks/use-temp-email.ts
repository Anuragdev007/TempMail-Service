import { useState, useCallback, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { TempMailAPI } from "@/lib/temp-mail-api";
import { useToast } from "@/hooks/use-toast";

export function useTempEmail() {
  const [currentEmail, setCurrentEmail] = useState<string>("");
  const [sidToken, setSidToken] = useState<string>("");
  const [expiresAt, setExpiresAt] = useState<Date | null>(null);
  const { toast } = useToast();

  // Load from localStorage on mount
  useEffect(() => {
    const savedEmail = localStorage.getItem('tempmail_current_email');
    const savedToken = localStorage.getItem('tempmail_sid_token');
    const savedExpiry = localStorage.getItem('tempmail_expires_at');
    
    if (savedEmail && savedToken && savedExpiry) {
      const expiryDate = new Date(savedExpiry);
      if (expiryDate > new Date()) {
        setCurrentEmail(savedEmail);
        setSidToken(savedToken);
        setExpiresAt(expiryDate);
      } else {
        // Clear expired data
        localStorage.removeItem('tempmail_current_email');
        localStorage.removeItem('tempmail_sid_token');
        localStorage.removeItem('tempmail_expires_at');
      }
    }
  }, []);

  const generateEmailMutation = useMutation({
    mutationFn: TempMailAPI.generateEmail,
    onSuccess: (data) => {
      const newExpiresAt = new Date(data.expiresAt);
      
      // Save to localStorage
      localStorage.setItem('tempmail_current_email', data.emailAddress);
      localStorage.setItem('tempmail_sid_token', data.sidToken);
      localStorage.setItem('tempmail_expires_at', newExpiresAt.toISOString());
      
      // Update state
      setCurrentEmail(data.emailAddress);
      setSidToken(data.sidToken);
      setExpiresAt(newExpiresAt);
      
      toast({
        title: "Success",
        description: "New temporary email generated!",
      });
    },
    onError: (error: any) => {
      console.error("Error generating email:", error);
      toast({
        title: "Error",
        description: "Failed to generate email. Please try again.",
        variant: "destructive",
      });
    },
  });

  const extendTimerMutation = useMutation({
    mutationFn: () => TempMailAPI.extendTimer(currentEmail),
    onSuccess: (data) => {
      setExpiresAt(new Date(data.expiresAt));
    },
    onError: (error: any) => {
      console.error("Error extending timer:", error);
      throw error; // Re-throw to handle in component
    },
  });

  const generateEmail = useCallback(() => {
    generateEmailMutation.mutate();
  }, [generateEmailMutation]);

  const extendTimer = useCallback(async () => {
    if (!currentEmail) {
      throw new Error("No active email to extend");
    }
    return extendTimerMutation.mutateAsync();
  }, [currentEmail, extendTimerMutation]);

  return {
    currentEmail,
    sidToken,
    expiresAt,
    generateEmail,
    extendTimer,
    isGenerating: generateEmailMutation.isPending,
    isExtending: extendTimerMutation.isPending,
  };
}
