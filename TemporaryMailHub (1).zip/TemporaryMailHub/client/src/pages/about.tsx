import { Link } from "wouter";
import { ArrowLeft, Mail, Shield, Clock, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6 text-foreground hover:bg-muted">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to TempMail
          </Button>
        </Link>

        <div className="space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">About TempMail Pro</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Your trusted provider of anonymous, temporary email addresses for secure online communication.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-card border border-border rounded-xl p-6">
              <Mail className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-3">Instant Email Generation</h3>
              <p className="text-muted-foreground">
                Generate temporary email addresses instantly without registration. Perfect for one-time signups,
                downloads, and protecting your real email from spam.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <Shield className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-3">Privacy Protection</h3>
              <p className="text-muted-foreground">
                Keep your personal email private. Our temporary emails help you avoid spam, 
                unwanted marketing, and protect your digital identity online.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <Clock className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-3">Auto-Expiration</h3>
              <p className="text-muted-foreground">
                Standard emails expire after 10 minutes, automatically cleaning up and ensuring 
                no long-term data storage. Premium users get 24-hour custom domain emails.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <Globe className="w-12 h-12 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-3">Global Accessibility</h3>
              <p className="text-muted-foreground">
                Access TempMail Pro from anywhere in the world. No geographical restrictions,
                no complex setups - just instant temporary email addresses.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              TempMail Pro was created to give internet users control over their digital privacy. 
              In an age where every website asks for your email address, we provide a simple solution 
              to maintain your anonymity while staying connected.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-500 mb-2">10M+</div>
                <div className="text-muted-foreground">Emails Generated</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-500 mb-2">500K+</div>
                <div className="text-muted-foreground">Users Protected</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-500 mb-2">99.9%</div>
                <div className="text-muted-foreground">Uptime</div>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">Why Choose TempMail Pro?</h2>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-muted-foreground">
                  <strong className="text-foreground">No Registration Required:</strong> Start using temporary emails immediately
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-muted-foreground">
                  <strong className="text-foreground">Real-Time Inbox:</strong> Receive emails instantly with live updates
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-muted-foreground">
                  <strong className="text-foreground">Multiple Domains:</strong> Choose from various email domains
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-muted-foreground">
                  <strong className="text-foreground">Premium Features:</strong> 24-hour custom domain emails for authenticated users
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-muted-foreground">
                  <strong className="text-foreground">Mobile Friendly:</strong> Works perfectly on all devices
                </p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <p className="text-muted-foreground mb-4">
              Questions about TempMail Pro? Need help or have feedback?
            </p>
            <Link href="/contact">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                Contact Support
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}