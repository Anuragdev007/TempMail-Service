import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, ArrowLeft, ExternalLink, UserIcon, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface PurchaseData {
  purchaseId: string;
  redirectUrl: string;
  amount: string;
  status: string;
}

const CheckoutForm = ({ purchaseData }: { purchaseData: PurchaseData | null }) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!purchaseData) {
      toast({
        title: "Error",
        description: "Purchase data not available. Please try again.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Redirect to AirTM checkout
      window.open(purchaseData.redirectUrl, '_blank');
      
      toast({
        title: "Redirected to AirTM",
        description: "Complete your payment on the AirTM page that just opened.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to redirect to payment page.",
        variant: "destructive",
      });
    }

    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
        <h4 className="font-semibold text-foreground mb-3 text-lg">Payment Method: AirTM</h4>
        <p className="text-muted-foreground text-base leading-relaxed mb-4">
          You'll be redirected to AirTM's secure payment page to complete your purchase. 
          AirTM supports 500+ payment methods including bank transfers, digital wallets, and more.
        </p>
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4">
          <p className="text-amber-700 dark:text-amber-300 text-sm font-medium">
            📋 Note: AirTM integration requires merchant account setup. The payment will redirect to AirTM's platform.
          </p>
        </div>
      </div>
      
      <Button 
        type="submit" 
        disabled={!purchaseData || isLoading}
        className="w-full gradient-primary"
        size="lg"
      >
        {isLoading ? (
          <>
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
            Redirecting...
          </>
        ) : (
          <>
            <ExternalLink className="w-4 h-4 mr-2" />
            Pay with AirTM - $4.99/month
          </>
        )}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [purchaseData, setPurchaseData] = useState<PurchaseData | null>(null);
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Mutation for upgrading to premium for authenticated users
  const premiumUpgradeMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/upgrade-premium"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Premium Activated!",
        description: "You now have access to 24-hour custom domain emails.",
      });
    },
    onError: (error) => {
      console.error('Error upgrading to premium:', error);
      toast({
        title: "Upgrade Failed",
        description: "Failed to activate premium features. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    // Only create purchase for non-authenticated users
    if (!isLoading && !isAuthenticated) {
      apiRequest("POST", "/api/create-purchase", { amount: 4.99 })
        .then((res) => res.json())
        .then((data) => {
          setPurchaseData(data);
        })
        .catch((error) => {
          console.error('Error creating purchase:', error);
          toast({
            title: "Error",
            description: "Failed to initialize payment. Please try again.",
            variant: "destructive",
          });
        });
    }
  }, [toast, isAuthenticated, isLoading]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Authenticated user - already premium
  if (isAuthenticated && user?.isPremium) {
    return (
      <div className="min-h-screen bg-background py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/">
            <Button variant="ghost" className="mb-6 text-foreground hover:bg-muted">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to TempMail
            </Button>
          </Link>

          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-4">
                <Crown className="w-8 h-8 text-black" />
              </div>
              <CardTitle className="text-2xl text-foreground">You're Already Premium!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground">
                You already have access to all premium features including 24-hour custom domain emails.
              </p>
              
              <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-lg p-4">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="font-semibold text-foreground">Premium Active</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Expires: {user.premiumExpiresAt ? new Date(user.premiumExpiresAt).toLocaleDateString() : 'Never'}
                </p>
              </div>

              <Link href="/">
                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                  Go to TempMail Pro
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Authenticated user - not premium yet (seamless upgrade)
  if (isAuthenticated && user && !user.isPremium) {
    return (
      <div className="min-h-screen bg-background py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/">
            <Button variant="ghost" className="mb-6 text-foreground hover:bg-muted">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to TempMail
            </Button>
          </Link>

          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 gradient-primary rounded-full flex items-center justify-center mb-4">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl text-foreground">Upgrade to Premium</CardTitle>
              <p className="text-muted-foreground">
                Welcome back, {user.firstName || 'User'}! Upgrade your account to unlock premium features.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20 rounded-lg p-6">
                <h3 className="font-semibold text-foreground mb-3">✨ Premium Features</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ 24-hour email retention (vs 10 minutes)</li>
                  <li>✓ Custom domain options</li>
                  <li>✓ Priority customer support</li>
                  <li>✓ Advanced email management</li>
                  <li>✓ No advertisements</li>
                </ul>
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold text-foreground mb-2">$4.99</div>
                <div className="text-sm text-muted-foreground">One-time payment for 30 days</div>
              </div>

              <Button 
                onClick={() => premiumUpgradeMutation.mutate()}
                disabled={premiumUpgradeMutation.isPending}
                className="w-full gradient-primary text-white text-lg py-6"
              >
                {premiumUpgradeMutation.isPending ? (
                  <>
                    <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Activating Premium...
                  </>
                ) : (
                  <>
                    <Crown className="w-5 h-5 mr-2" />
                    Activate Premium Now
                  </>
                )}
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                Since you're already signed in, premium features will be activated instantly.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Non-authenticated user - requires payment
  if (!purchaseData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6 text-foreground hover:bg-muted">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to TempMail
          </Button>
        </Link>

        <Card className="shadow-2xl bg-card/80 backdrop-blur-sm border-border/50">
          <CardHeader className="text-center pb-8">
            <div className="w-20 h-20 gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Crown className="text-white text-3xl" />
            </div>
            <CardTitle className="text-3xl text-foreground">
              Upgrade to Premium
            </CardTitle>
            <p className="text-muted-foreground mt-3 text-lg">
              Get 24-hour custom domain emails and premium features
            </p>
          </CardHeader>
          
          <CardContent className="space-y-8">
            <div className="bg-primary/10 rounded-2xl p-8 border border-primary/20">
              <h3 className="font-bold text-foreground mb-6 text-xl">Premium Features:</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <span className="text-foreground text-base">24-hour email validity (vs 10 minutes)</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <span className="text-foreground text-base">Custom domain email addresses</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <span className="text-foreground text-base">Priority customer support</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <span className="text-foreground text-base">Ad-free experience</span>
                </div>
              </div>
            </div>

            <CheckoutForm purchaseData={purchaseData} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
