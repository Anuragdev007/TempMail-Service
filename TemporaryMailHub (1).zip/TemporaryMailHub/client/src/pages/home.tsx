import { useState } from "react";
import EmailGenerator from "@/components/email-generator";
import InboxPanel from "@/components/inbox-panel";
import Sidebar from "@/components/sidebar";
import EmailModal from "@/components/email-modal";
import { Crown, Mail, User as UserIcon, LogOut, Info, MessageSquare, Shield, Menu } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import type { EmailMessage, User as UserType } from "@shared/schema";

export default function Home() {
  const [selectedEmail, setSelectedEmail] = useState<EmailMessage | null>(null);
  const [currentEmailAddress, setCurrentEmailAddress] = useState<string>("");
  const [emailCount, setEmailCount] = useState(0);
  const { user, isAuthenticated, isLoading } = useAuth();

  const handleEmailSelect = (email: EmailMessage) => {
    setSelectedEmail(email);
  };

  const handleCloseModal = () => {
    setSelectedEmail(null);
  };

  return (
    <div className="min-h-screen bg-background font-sans antialiased">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur-sm border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center shadow-lg">
                <Mail className="text-white text-xl" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">TempMail Pro</h1>
                <p className="text-sm text-muted-foreground">Anonymous temporary email service</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Navigation Links */}
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/about">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <Info className="w-4 h-4 mr-1" />
                    About
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <MessageSquare className="w-4 h-4 mr-1" />
                    Contact
                  </Button>
                </Link>
                <Link href="/privacy">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <Shield className="w-4 h-4 mr-1" />
                    Privacy
                  </Button>
                </Link>
              </nav>

              {/* Authentication Section */}
              {isLoading ? (
                <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" />
              ) : isAuthenticated && user ? (
                <div className="flex items-center space-x-3">
                  {user.isPremium && (
                    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-semibold">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center space-x-2">
                        {user.profileImageUrl ? (
                          <img 
                            src={user.profileImageUrl} 
                            alt="Profile" 
                            className="w-8 h-8 rounded-full object-cover" 
                          />
                        ) : (
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                            <UserIcon className="w-4 h-4 text-white" />
                          </div>
                        )}
                        <span className="text-foreground">{user.firstName || user.email}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem disabled>
                        <span className="text-xs text-muted-foreground">
                          {user.isPremium ? 'Premium Account' : 'Free Account'}
                        </span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {!user.isPremium && (
                        <>
                          <DropdownMenuItem asChild>
                            <Link href="/checkout" className="w-full">
                              <Crown className="w-4 h-4 mr-2" />
                              Upgrade to Premium
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                        </>
                      )}
                      <DropdownMenuItem asChild>
                        <a href="/api/logout" className="w-full">
                          <LogOut className="w-4 h-4 mr-2" />
                          Sign Out
                        </a>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ) : (
                <div className="flex items-center space-x-3">
                  <a href="/api/login">
                    <Button variant="outline" size="sm">
                      <UserIcon className="w-4 h-4 mr-2" />
                      Sign In
                    </Button>
                  </a>
                  <Link href="/checkout">
                    <Button className="gradient-primary text-white px-6 py-2 rounded-xl font-semibold hover:shadow-xl transition-all duration-300">
                      <Crown className="w-4 h-4 mr-2" />
                      Go Premium
                    </Button>
                  </Link>
                </div>
              )}

              {/* Mobile Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="md:hidden">
                    <Menu className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem asChild>
                    <Link href="/about" className="w-full">About</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/contact" className="w-full">Contact</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/privacy" className="w-full">Privacy</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Top Banner Ad Space */}
        <div className="mb-8">
          <div className="bg-muted/30 border border-dashed border-muted-foreground/20 rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground">Advertisement Space (728x90)</p>
            <div className="h-20 bg-muted/50 rounded flex items-center justify-center">
              <span className="text-xs text-muted-foreground">Google AdSense Banner Ad</span>
            </div>
          </div>
        </div>

        <EmailGenerator 
          onEmailGenerated={setCurrentEmailAddress}
          isPremium={user?.isPremium || false}
        />

        {/* Mid-content Ad Space */}
        <div className="my-8">
          <div className="bg-muted/30 border border-dashed border-muted-foreground/20 rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground">Advertisement Space (300x250)</p>
            <div className="h-64 bg-muted/50 rounded flex items-center justify-center">
              <span className="text-xs text-muted-foreground">Google AdSense Medium Rectangle</span>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <InboxPanel 
              emailAddress={currentEmailAddress}
              onEmailSelect={handleEmailSelect}
              onEmailCountChange={setEmailCount}
            />
          </div>
          <div className="lg:col-span-1 space-y-6">
            {/* Sidebar Ad Space */}
            <div className="bg-muted/30 border border-dashed border-muted-foreground/20 rounded-lg p-4 text-center">
              <p className="text-sm text-muted-foreground">Advertisement Space (300x600)</p>
              <div className="h-96 bg-muted/50 rounded flex items-center justify-center">
                <span className="text-xs text-muted-foreground">Google AdSense Skyscraper</span>
              </div>
            </div>
            
            <Sidebar emailCount={emailCount} />
            
            {/* Second Sidebar Ad */}
            <div className="bg-muted/30 border border-dashed border-muted-foreground/20 rounded-lg p-4 text-center">
              <p className="text-sm text-muted-foreground">Advertisement Space (300x250)</p>
              <div className="h-64 bg-muted/50 rounded flex items-center justify-center">
                <span className="text-xs text-muted-foreground">Google AdSense Square</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Ad Space */}
        <div className="mt-12">
          <div className="bg-muted/30 border border-dashed border-muted-foreground/20 rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground">Advertisement Space (728x90)</p>
            <div className="h-20 bg-muted/50 rounded flex items-center justify-center">
              <span className="text-xs text-muted-foreground">Google AdSense Footer Banner</span>
            </div>
          </div>
        </div>

        {/* Footer with additional content for SEO */}
        <footer className="mt-16 pt-8 border-t border-border">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold text-foreground mb-3">TempMail Pro</h3>
              <p className="text-sm text-muted-foreground">
                Secure, anonymous temporary email addresses for privacy protection and spam prevention.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Features</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>10-minute temporary emails</li>
                <li>Real-time inbox updates</li>
                <li>No registration required</li>
                <li>Premium 24-hour emails</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Support</h4>
              <ul className="space-y-1 text-sm">
                <li><Link href="/contact" className="text-muted-foreground hover:text-foreground">Contact Us</Link></li>
                <li><Link href="/about" className="text-muted-foreground hover:text-foreground">About</Link></li>
                <li><Link href="/privacy" className="text-muted-foreground hover:text-foreground">Privacy Policy</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Premium</h4>
              <ul className="space-y-1 text-sm">
                <li className="text-muted-foreground">24-hour email retention</li>
                <li className="text-muted-foreground">Custom domain options</li>
                <li className="text-muted-foreground">Priority support</li>
                <li>
                  <Link href="/checkout" className="text-purple-500 hover:text-purple-400">
                    Upgrade Now →
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="text-center text-sm text-muted-foreground">
            <p>&copy; 2025 TempMail Pro. All rights reserved. | Anonymous temporary email service for privacy protection.</p>
          </div>
        </footer>
      </main>

      {selectedEmail && (
        <EmailModal 
          email={selectedEmail}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}
