import { Link } from "wouter";
import { ArrowLeft, Shield, Eye, Database, Lock, Globe, UserCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="mb-6 text-foreground hover:bg-muted">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to TempMail
          </Button>
        </Link>

        <div className="space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Privacy Policy</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Your privacy is our priority. Learn how we protect your data and ensure your anonymity.
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Last updated: January 4, 2025
            </p>
          </div>

          <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center space-x-3 mb-3">
              <Shield className="w-6 h-6 text-green-500" />
              <h2 className="text-xl font-bold text-foreground">Privacy at a Glance</h2>
            </div>
            <ul className="space-y-2 text-muted-foreground">
              <li>✓ No personal data collection for basic service</li>
              <li>✓ Temporary emails auto-delete after expiration</li>
              <li>✓ No tracking or profiling of users</li>
              <li>✓ Optional authentication only for premium features</li>
              <li>✓ All data encrypted in transit and at rest</li>
            </ul>
          </div>

          <div className="space-y-8">
            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Eye className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">What Information We Collect</h2>
              </div>
              <div className="space-y-4 text-muted-foreground">
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">For Anonymous Users (No Account)</h3>
                  <ul className="space-y-1 text-sm">
                    <li>• Generated temporary email addresses (automatically deleted)</li>
                    <li>• Received email messages (automatically deleted with email)</li>
                    <li>• Basic usage analytics (anonymized)</li>
                    <li>• No IP addresses, browser fingerprints, or personal data</li>
                  </ul>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">For Premium Users (With Account)</h3>
                  <ul className="space-y-1 text-sm">
                    <li>• Replit authentication data (ID, email, name if provided)</li>
                    <li>• Premium subscription status and expiration</li>
                    <li>• Extended email retention preferences</li>
                    <li>• Account creation and last login dates</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Database className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">How We Use Your Information</h2>
              </div>
              <div className="space-y-3 text-muted-foreground">
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-foreground">Service Provision</h3>
                  <p>Generate temporary emails, receive messages, and provide real-time inbox functionality.</p>
                </div>
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-foreground">Premium Features</h3>
                  <p>For authenticated users, provide extended email retention and custom domain options.</p>
                </div>
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-foreground">Service Improvement</h3>
                  <p>Analyze anonymous usage patterns to improve performance and user experience.</p>
                </div>
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-foreground">Legal Compliance</h3>
                  <p>Comply with applicable laws and respond to valid legal requests when required.</p>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Lock className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">Data Protection & Security</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-3">Encryption</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• TLS 1.3 encryption for all data in transit</li>
                    <li>• AES-256 encryption for data at rest</li>
                    <li>• Secure database connections</li>
                    <li>• Regular security audits</li>
                  </ul>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-3">Access Controls</h3>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Role-based access control</li>
                    <li>• Multi-factor authentication for admin access</li>
                    <li>• Regular access reviews</li>
                    <li>• Principle of least privilege</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center space-x-3 mb-4">
                <UserCheck className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">Your Rights & Controls</h2>
              </div>
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Anonymous Users</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Since we don't collect personal data for anonymous users, your temporary emails 
                    automatically expire and are deleted. No action needed from you.
                  </p>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Premium Users</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li><strong className="text-foreground">Access:</strong> View your account data through your profile page</li>
                    <li><strong className="text-foreground">Rectification:</strong> Update your profile information</li>
                    <li><strong className="text-foreground">Deletion:</strong> Delete your account and all associated data</li>
                    <li><strong className="text-foreground">Portability:</strong> Export your data in standard formats</li>
                    <li><strong className="text-foreground">Withdrawal:</strong> Revoke consent and downgrade to anonymous usage</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Globe className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">Third-Party Services</h2>
              </div>
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Guerrilla Mail API</h3>
                  <p className="text-sm text-muted-foreground">
                    We use Guerrilla Mail's API to generate temporary email addresses and receive messages. 
                    Their privacy policy applies to the email generation service.
                  </p>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Replit Authentication</h3>
                  <p className="text-sm text-muted-foreground">
                    Premium users authenticate through Replit's secure OpenID Connect service. 
                    We only receive basic profile information you consent to share.
                  </p>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Analytics</h3>
                  <p className="text-sm text-muted-foreground">
                    We use privacy-focused analytics to understand usage patterns. 
                    All data is anonymized and aggregated.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <div className="flex items-center space-x-3 mb-4">
                <Shield className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold text-foreground">Data Retention</h2>
              </div>
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Automatic Deletion</h3>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Standard emails: 10 minutes</li>
                      <li>• Premium emails: 24 hours</li>
                      <li>• Anonymous usage data: 30 days</li>
                      <li>• Error logs: 7 days</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-foreground mb-3">Account Data</h3>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Active premium accounts: Retained during subscription</li>
                      <li>• Cancelled accounts: 30 days then deleted</li>
                      <li>• Inactive accounts: 1 year then deleted</li>
                      <li>• Legal hold: As required by law</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-foreground mb-4">Contact Information</h2>
              <div className="bg-card border border-border rounded-lg p-6">
                <p className="text-muted-foreground mb-4">
                  For privacy-related questions, data requests, or concerns about this policy:
                </p>
                <div className="space-y-2 text-sm">
                  <div>
                    <strong className="text-foreground">Email:</strong>
                    <span className="text-muted-foreground ml-2">privacy@tempmail.pro</span>
                  </div>
                  <div>
                    <strong className="text-foreground">Response Time:</strong>
                    <span className="text-muted-foreground ml-2">Within 48 hours</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-6 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    This privacy policy may be updated periodically. We'll notify users of significant 
                    changes through our website. Continued use after changes indicates acceptance of the updated policy.
                  </p>
                </div>
              </div>
            </section>
          </div>

          <div className="text-center">
            <p className="text-muted-foreground mb-4">
              Have questions about our privacy practices?
            </p>
            <Link href="/contact">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                Contact Support
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}