import { apiRequest } from "./queryClient";

export interface TempEmailResponse {
  emailAddress: string;
  expiresAt: string;
  sidToken: string;
}

export interface EmailMessage {
  id: number;
  mailId: string;
  subject: string;
  sender: string;
  body: string;
  receivedAt: string;
}

export interface MessagesResponse {
  messages: EmailMessage[];
  count: number;
}

export class TempMailAPI {
  static async generateEmail(): Promise<TempEmailResponse> {
    const response = await apiRequest("POST", "/api/temp-email/generate");
    return response.json();
  }

  static async getMessages(emailAddress: string): Promise<MessagesResponse> {
    const response = await apiRequest("GET", `/api/temp-email/${emailAddress}/messages`);
    return response.json();
  }

  static async getMessage(emailAddress: string, messageId: string): Promise<EmailMessage> {
    const response = await apiRequest("GET", `/api/temp-email/${emailAddress}/messages/${messageId}`);
    return response.json();
  }

  static async extendTimer(emailAddress: string): Promise<{ expiresAt: string }> {
    const response = await apiRequest("POST", `/api/temp-email/${emailAddress}/extend`);
    return response.json();
  }
}
