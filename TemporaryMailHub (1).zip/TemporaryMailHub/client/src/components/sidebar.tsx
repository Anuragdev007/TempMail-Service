import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, CheckCircle, HelpCircle, Shield, LifeBuoy, Accessibility } from "lucide-react";
import { Link } from "wouter";

interface SidebarProps {
  emailCount: number;
}

export default function Sidebar({ emailCount }: SidebarProps) {
  return (
    <div className="space-y-6">
      {/* Advertisement Space */}
      <Card className="shadow-2xl bg-card/80 backdrop-blur-sm border-border/50">
        <CardContent className="p-6 text-center">
          <div className="bg-muted/30 border-2 border-dashed border-border rounded-xl p-8">
            <Accessibility className="text-muted-foreground text-3xl mb-4 mx-auto" />
            <p className="text-muted-foreground text-sm">
              Advertisement Space<br/>
              <span className="text-xs">Powered by Google AdSense</span>
            </p>
            {/* Google AdSense code would go here */}
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossOrigin="anonymous"></script>
          </div>
        </CardContent>
      </Card>

      {/* Premium Features */}
      <Card className="shadow-2xl overflow-hidden bg-card/80 backdrop-blur-sm border-border/50">
        <div className="gradient-primary p-8 text-white">
          <div className="text-center mb-6">
            <Crown className="text-4xl mb-4 mx-auto" />
            <CardTitle className="text-xl text-white">
              Upgrade to Premium
            </CardTitle>
            <p className="text-purple-100 text-base mt-2">
              Get custom domain emails & more
            </p>
          </div>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3">
              <CheckCircle className="text-green-300 w-6 h-6 flex-shrink-0" />
              <span className="text-base">24-hour email validity</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="text-green-300 w-6 h-6 flex-shrink-0" />
              <span className="text-base">Custom domain emails</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="text-green-300 w-6 h-6 flex-shrink-0" />
              <span className="text-base">Priority support</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="text-green-300 w-6 h-6 flex-shrink-0" />
              <span className="text-base">No advertisements</span>
            </div>
          </div>
          
          <Link href="/checkout">
            <Button className="w-full bg-white text-purple-700 hover:bg-purple-50 shadow-lg hover:shadow-xl transition-all duration-300 py-3 text-base font-semibold">
              Pay with AirTM - $4.99/month
            </Button>
          </Link>
        </div>
      </Card>

      {/* Quick Stats */}
      <Card className="shadow-2xl bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <CardTitle className="text-xl text-foreground">Quick Stats</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-base">Emails received</span>
            <span className="font-bold text-foreground text-lg">{emailCount}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground text-base">Status</span>
            <span className="px-3 py-2 bg-green-500/20 text-green-400 rounded-xl text-sm font-semibold border border-green-500/30">
              ● Active
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Help & Support */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg">Need Help?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <a 
            href="#" 
            className="flex items-center space-x-3 text-gray-600 hover:text-primary transition-colors duration-150"
          >
            <HelpCircle className="w-4 h-4" />
            <span className="text-sm">How it works</span>
          </a>
          <a 
            href="#" 
            className="flex items-center space-x-3 text-gray-600 hover:text-primary transition-colors duration-150"
          >
            <Shield className="w-4 h-4" />
            <span className="text-sm">Privacy policy</span>
          </a>
          <a 
            href="#" 
            className="flex items-center space-x-3 text-gray-600 hover:text-primary transition-colors duration-150"
          >
            <LifeBuoy className="w-4 h-4" />
            <span className="text-sm">Contact support</span>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
