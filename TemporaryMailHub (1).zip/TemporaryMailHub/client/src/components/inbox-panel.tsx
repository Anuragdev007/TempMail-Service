import { useEffect, useState, useRef } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Inbox, Mail, Share } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { EmailMessage } from "@shared/schema";

interface InboxPanelProps {
  emailAddress: string;
  onEmailSelect: (email: EmailMessage) => void;
  onEmailCountChange: (count: number) => void;
}

export default function InboxPanel({ emailAddress, onEmailSelect, onEmailCountChange }: InboxPanelProps) {
  const [isLive, setIsLive] = useState(true);
  const { toast } = useToast();
  const previousMessageCount = useRef(0);

  // Request notification permission on component mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  const { data: messagesData, isLoading } = useQuery({
    queryKey: [`/api/temp-email/${emailAddress}/messages`],
    enabled: !!emailAddress,
    refetchInterval: isLive ? 5000 : false, // Poll every 5 seconds when live
    refetchIntervalInBackground: false,
  });

  const messages = messagesData?.messages || [];

  useEffect(() => {
    onEmailCountChange(messages.length);
    
    // Show notification for new emails
    if (messages.length > previousMessageCount.current && previousMessageCount.current > 0) {
      const newEmailsCount = messages.length - previousMessageCount.current;
      toast({
        title: "New Email Received!",
        description: `You have ${newEmailsCount} new email${newEmailsCount > 1 ? 's' : ''} in your inbox`,
      });
      
      // Browser notification if permission granted
      if (Notification.permission === 'granted') {
        new Notification('TempMail - New Email', {
          body: `You have ${newEmailsCount} new email${newEmailsCount > 1 ? 's' : ''}`,
          icon: '/favicon.ico'
        });
      }
    }
    
    previousMessageCount.current = messages.length;
  }, [messages.length, onEmailCountChange, toast]);

  const formatTimestamp = (date: string | Date | null) => {
    if (!date) return 'Unknown';
    
    const messageDate = new Date(date);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60));
    
    if (diffMinutes < 1) return 'Just now';
    if (diffMinutes < 60) return `${diffMinutes} min${diffMinutes !== 1 ? 's' : ''} ago`;
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    
    return messageDate.toLocaleDateString();
  };

  const handleEmailClick = (message: EmailMessage) => {
    onEmailSelect(message);
  };

  if (!emailAddress) {
    return (
      <Card className="shadow-2xl bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-3">
            <h3 className="text-xl font-semibold text-foreground">Inbox</h3>
            <Badge variant="secondary" className="bg-muted text-muted-foreground">Waiting for email...</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
            <div className="w-20 h-20 bg-muted/50 rounded-2xl flex items-center justify-center mb-6">
              <Inbox className="text-muted-foreground text-3xl" />
            </div>
            <h4 className="text-xl font-semibold text-foreground mb-3">Generate an email first</h4>
            <p className="text-muted-foreground max-w-sm text-base">
              Click "New Email" above to generate a temporary email address and start receiving messages.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-2xl bg-card/80 backdrop-blur-sm border-border/50">
      <CardHeader className="pb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-xl font-semibold text-foreground">Inbox</h3>
            <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
              {messages.length} email{messages.length !== 1 ? 's' : ''}
            </Badge>
          </div>
          <div className="flex items-center space-x-3">
            <div className="pulse-animation w-3 h-3 bg-green-400 rounded-full shadow-lg"></div>
            <span className="text-sm text-muted-foreground font-medium">Live updates</span>
          </div>
        </div>
      </CardHeader>
        
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
              <div className="w-20 h-20 bg-muted/50 rounded-2xl flex items-center justify-center mb-6">
                <Inbox className="text-muted-foreground text-3xl" />
              </div>
              <h4 className="text-xl font-semibold text-foreground mb-3">No emails yet</h4>
              <p className="text-muted-foreground max-w-sm text-base">
                Your temporary email is ready to receive messages. Share the address above to start receiving emails.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              {messages.map((message: EmailMessage) => (
                <div
                  key={message.id}
                  onClick={() => handleEmailClick(message)}
                  className="p-6 hover:bg-muted/30 transition-colors duration-200 cursor-pointer border-l-4 border-l-transparent hover:border-l-primary/50"
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-primary/15 rounded-xl flex items-center justify-center shadow-sm">
                      <Mail className="text-primary w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-base font-bold text-foreground truncate">
                          {message.sender}
                        </h4>
                        <span className="text-sm text-muted-foreground font-medium bg-muted/50 px-2 py-1 rounded-lg">
                          {formatTimestamp(message.receivedAt)}
                        </span>
                      </div>
                      <p className="text-base font-semibold text-foreground mb-2 truncate">
                        {message.subject}
                      </p>
                      <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                        {message.body?.replace(/<[^>]*>/g, '').substring(0, 120)}...
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          // TODO: Implement forward functionality
                        }}
                        className="text-muted-foreground hover:text-primary transition-colors duration-200" 
                        title="Forward email"
                      >
                        <Share className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
  );
}
