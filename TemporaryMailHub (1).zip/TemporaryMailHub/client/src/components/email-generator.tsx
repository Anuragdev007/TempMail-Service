import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Copy, Clock, RefreshCw } from "lucide-react";
import { useTempEmail } from "@/hooks/use-temp-email";

interface EmailGeneratorProps {
  onEmailGenerated: (email: string) => void;
  isPremium?: boolean;
}

export default function EmailGenerator({ onEmailGenerated, isPremium = false }: EmailGeneratorProps) {
  const { toast } = useToast();
  const { currentEmail, generateEmail, extendTimer, isGenerating } = useTempEmail();
  const [timeRemaining, setTimeRemaining] = useState(600); // 10 minutes
  const [extendCount, setExtendCount] = useState(0); // Track how many times extended
  const hasGeneratedInitial = useRef(false);

  useEffect(() => {
    if (currentEmail) {
      onEmailGenerated(currentEmail);
      setTimeRemaining(600); // Reset timer when new email is generated
    }
  }, [currentEmail, onEmailGenerated]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          // Don't auto-generate, just show expired state
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleCopyEmail = async () => {
    if (!currentEmail) return;
    
    try {
      await navigator.clipboard.writeText(currentEmail);
      toast({
        title: "Success",
        description: "Email address copied to clipboard!",
      });
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to copy email address",
        variant: "destructive",
      });
    }
  };

  const handleExtendTimer = async () => {
    // Check if already extended 6 times (1 hour maximum)
    if (extendCount >= 6) {
      toast({
        title: "Limit Reached",
        description: "Maximum extension time of 1 hour reached. Generate a new email instead.",
        variant: "destructive",
      });
      return;
    }

    try {
      await extendTimer();
      setTimeRemaining(prev => prev + 600); // Add 10 minutes
      setExtendCount(prev => prev + 1);
      toast({
        title: "Success",
        description: `Timer extended by 10 minutes! (${extendCount + 1}/6 extensions used)`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to extend timer",
        variant: "destructive",
      });
    }
  };

  const handleGenerateNew = () => {
    generateEmail();
    setTimeRemaining(600);
    setExtendCount(0); // Reset extend count for new email
  };

  // Generate initial email on mount (only once)
  useEffect(() => {
    if (!currentEmail && !hasGeneratedInitial.current) {
      hasGeneratedInitial.current = true;
      generateEmail();
    }
  }, []); // Empty dependency array to run only once

  return (
    <Card className="bg-card/80 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden mb-12 border border-border/50">
      <div className="email-display p-12 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-3">Your Temporary Email</h2>
          <p className="text-purple-100 mb-8 text-lg">
            {timeRemaining > 0 ? "Ready to use • Auto-expires in 10 minutes" : "⚠️ Email expired • Generate a new one"}
          </p>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-8 border border-white/20">
            <div className="flex items-center justify-center space-x-6 flex-wrap">
              <span className="text-3xl md:text-4xl font-bold text-white break-all tracking-wide">
                {currentEmail || "Generating..."}
              </span>
              <Button
                onClick={handleCopyEmail}
                disabled={!currentEmail}
                className="bg-white/20 hover:bg-white/30 text-white border-white/30 shadow-lg"
                size="lg"
              >
                <Copy className="w-5 h-5 mr-2" />
                Copy
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-center space-x-8 flex-wrap gap-4">
            <div className={`text-center bg-white/5 rounded-xl p-6 min-w-[120px] ${timeRemaining === 0 ? 'border-2 border-red-400' : ''}`}>
              <div className={`text-4xl font-bold mb-2 ${timeRemaining === 0 ? 'text-red-400' : 'text-white'}`}>
                {timeRemaining === 0 ? "EXPIRED" : formatTime(timeRemaining)}
              </div>
              <div className="text-purple-100 text-sm font-medium">
                {timeRemaining === 0 ? "Generate new email" : "Time remaining"}
              </div>
            </div>
            
            <Button
              onClick={handleExtendTimer}
              disabled={!currentEmail || timeRemaining === 0 || extendCount >= 6}
              className="bg-white/90 text-purple-700 hover:bg-white hover:shadow-xl transition-all duration-300 px-6 py-3 disabled:opacity-50"
              size="lg"
            >
              <Clock className="w-5 h-5 mr-2" />
              Extend Time ({extendCount}/6)
            </Button>
            
            <Button
              onClick={handleGenerateNew}
              disabled={isGenerating}
              className="bg-green-500 hover:bg-green-600 text-white shadow-lg hover:shadow-xl transition-all duration-300 px-6 py-3"
              size="lg"
            >
              <RefreshCw className={`w-5 h-5 mr-2 ${isGenerating ? 'animate-spin' : ''}`} />
              New Email
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
