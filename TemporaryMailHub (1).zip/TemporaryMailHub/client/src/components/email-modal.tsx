import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Share, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { EmailMessage } from "@shared/schema";

interface EmailModalProps {
  email: EmailMessage;
  onClose: () => void;
}

export default function EmailModal({ email, onClose }: EmailModalProps) {
  const [open, setOpen] = useState(true);

  const { data: fullEmail, isLoading } = useQuery({
    queryKey: [`/api/temp-email/messages/${email.mailId}`],
    enabled: !!email.mailId,
  });

  const handleClose = () => {
    setOpen(false);
    onClose();
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleString();
  };

  const handleForward = () => {
    // TODO: Implement forward functionality
    console.log("Forward email:", email);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="text-lg font-semibold">Email Details</DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        ) : (
          <div className="space-y-4 overflow-y-auto max-h-96">
            <div>
              <label className="text-sm font-medium text-gray-700">From:</label>
              <p className="text-gray-900 mt-1">{email.sender}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Subject:</label>
              <p className="text-gray-900 mt-1">{email.subject}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Date:</label>
              <p className="text-gray-900 mt-1">{formatDate(email.receivedAt)}</p>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700">Message:</label>
              <div className="bg-gray-50 rounded-lg p-4 mt-2">
                <div 
                  className="text-gray-900 whitespace-pre-wrap"
                  dangerouslySetInnerHTML={{ 
                    __html: fullEmail?.htmlBody || fullEmail?.body || email.body 
                  }}
                />
              </div>
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-end space-x-3 pt-4 border-t">
          <Button
            onClick={handleForward}
            className="bg-primary hover:bg-primary/90"
          >
            <Share className="w-4 h-4 mr-2" />
            Forward
          </Button>
          <Button
            variant="outline"
            onClick={handleClose}
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
