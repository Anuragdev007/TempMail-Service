import {
  pgTable,
  text,
  varchar,
  timestamp,
  integer,
  serial,
  boolean,
  jsonb,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  isPremium: boolean("is_premium").default(false),
  premiumExpiresAt: timestamp("premium_expires_at"),
});

export const tempEmails = pgTable("temp_emails", {
  id: serial("id").primaryKey(),
  emailAddress: text("email_address").notNull(),
  sidToken: text("sid_token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  userId: varchar("user_id"),
  isPremium: boolean("is_premium").default(false),
  customDomain: varchar("custom_domain"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailMessages = pgTable("email_messages", {
  id: serial("id").primaryKey(),
  tempEmailId: integer("temp_email_id").notNull(),
  mailId: text("mail_id").notNull(),
  subject: text("subject").notNull(),
  sender: text("sender").notNull(),
  body: text("body").notNull(),
  receivedAt: timestamp("received_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertTempEmailSchema = createInsertSchema(tempEmails).omit({
  id: true,
  createdAt: true,
});

export const insertEmailMessageSchema = createInsertSchema(emailMessages).omit({
  id: true,
  receivedAt: true,
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTempEmail = z.infer<typeof insertTempEmailSchema>;
export type TempEmail = typeof tempEmails.$inferSelect;
export type InsertEmailMessage = z.infer<typeof insertEmailMessageSchema>;
export type EmailMessage = typeof emailMessages.$inferSelect;
