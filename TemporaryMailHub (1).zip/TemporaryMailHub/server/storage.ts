import {
  users,
  tempEmails,
  emailMessages,
  type User,
  type UpsertUser,
  type TempEmail,
  type InsertTempEmail,
  type EmailMessage,
  type InsertEmailMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  upgradeToPremium(userId: string): Promise<User>;
  
  createTempEmail(tempEmail: InsertTempEmail): Promise<TempEmail>;
  getTempEmail(emailAddress: string): Promise<TempEmail | undefined>;
  getTempEmailById(id: number): Promise<TempEmail | undefined>;
  deleteTempEmail(id: number): Promise<void>;
  
  createEmailMessage(message: InsertEmailMessage): Promise<EmailMessage>;
  getEmailMessages(tempEmailId: number): Promise<EmailMessage[]>;
  deleteEmailMessage(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async upgradeToPremium(userId: string): Promise<User> {
    const premiumExpiresAt = new Date();
    premiumExpiresAt.setDate(premiumExpiresAt.getDate() + 30); // 30 days premium
    
    const [user] = await db
      .update(users)
      .set({ 
        isPremium: true, 
        premiumExpiresAt,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    
    return user;
  }

  async createTempEmail(insertTempEmail: InsertTempEmail): Promise<TempEmail> {
    const [tempEmail] = await db
      .insert(tempEmails)
      .values(insertTempEmail)
      .returning();
    return tempEmail;
  }

  async getTempEmail(emailAddress: string): Promise<TempEmail | undefined> {
    const [tempEmail] = await db.select().from(tempEmails).where(eq(tempEmails.emailAddress, emailAddress));
    return tempEmail || undefined;
  }

  async getTempEmailById(id: number): Promise<TempEmail | undefined> {
    const [tempEmail] = await db.select().from(tempEmails).where(eq(tempEmails.id, id));
    return tempEmail || undefined;
  }

  async deleteTempEmail(id: number): Promise<void> {
    // Delete associated messages first
    await db.delete(emailMessages).where(eq(emailMessages.tempEmailId, id));
    // Then delete the temp email
    await db.delete(tempEmails).where(eq(tempEmails.id, id));
  }

  async createEmailMessage(insertMessage: InsertEmailMessage): Promise<EmailMessage> {
    const [message] = await db
      .insert(emailMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getEmailMessages(tempEmailId: number): Promise<EmailMessage[]> {
    const messages = await db
      .select()
      .from(emailMessages)
      .where(eq(emailMessages.tempEmailId, tempEmailId))
      .orderBy(desc(emailMessages.receivedAt));
    return messages;
  }

  async deleteEmailMessage(id: number): Promise<void> {
    await db.delete(emailMessages).where(eq(emailMessages.id, id));
  }
}

export const storage = new DatabaseStorage();