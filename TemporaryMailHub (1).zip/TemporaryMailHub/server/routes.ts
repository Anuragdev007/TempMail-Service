import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTempEmailSchema, insertEmailMessageSchema } from "@shared/schema";
import { setupAuth, isAuthenticated } from "./replitAuth";

// Guerrilla Mail API helper functions
async function callGuerrillaAPI(params: Record<string, string>): Promise<any> {
  const url = new URL('https://api.guerrillamail.com/ajax.php');
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.append(key, value);
  });
  
  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Guerrilla Mail API error: ${response.statusText}`);
  }
  return response.json();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Premium upgrade route
  app.post('/api/upgrade-premium', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.upgradeToPremium(userId);
      res.json({ success: true, user });
    } catch (error) {
      console.error("Error upgrading to premium:", error);
      res.status(500).json({ message: "Failed to upgrade to premium" });
    }
  });
  
  // Generate temporary email
  app.post("/api/temp-email/generate", async (req, res) => {
    try {
      const data = await callGuerrillaAPI({
        f: 'get_email_address',
        ip: '127.0.0.1',
        agent: 'TempMailPro'
      });

      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now
      
      const tempEmail = await storage.createTempEmail({
        emailAddress: data.email_addr,
        sidToken: data.sid_token,
        expiresAt,
        userId: null,
        isPremium: false
      });

      res.json({
        emailAddress: tempEmail.emailAddress,
        expiresAt: tempEmail.expiresAt,
        sidToken: tempEmail.sidToken
      });
    } catch (error: any) {
      console.error('Error generating temp email:', error);
      res.status(500).json({ 
        message: "Failed to generate temporary email", 
        error: error.message 
      });
    }
  });

  // Check for new emails
  app.get("/api/temp-email/:emailAddress/messages", async (req, res) => {
    try {
      const { emailAddress } = req.params;
      const tempEmail = await storage.getTempEmail(emailAddress);
      
      if (!tempEmail) {
        return res.status(404).json({ message: "Email address not found" });
      }

      // Check if email has expired
      if (new Date() > tempEmail.expiresAt) {
        await storage.deleteTempEmail(tempEmail.id);
        return res.status(410).json({ message: "Email address has expired" });
      }

      // Get existing messages from storage
      const existingMessages = await storage.getEmailMessages(tempEmail.id);

      // Check Guerrilla Mail API for new messages
      try {
        const data = await callGuerrillaAPI({
          f: 'check_email',
          seq: '0',
          ip: '127.0.0.1',
          agent: 'TempMailPro',
          sid_token: tempEmail.sidToken
        });

        // Store new messages
        if (data.list && data.list.length > 0) {
          for (const message of data.list) {
            // Check if message already exists
            const messageExists = existingMessages.some(m => m.mailId === message.mail_id);
            if (!messageExists) {
              await storage.createEmailMessage({
                tempEmailId: tempEmail.id,
                mailId: message.mail_id,
                subject: message.mail_subject || 'No Subject',
                sender: message.mail_from || 'Unknown Sender',
                body: message.mail_body || message.mail_excerpt || ''
              });
            }
          }
        }
      } catch (apiError) {
        console.error('Guerrilla Mail API error:', apiError);
        // Continue with existing messages even if API fails
      }

      // Return updated messages from storage
      const allMessages = await storage.getEmailMessages(tempEmail.id);
      res.json({ 
        messages: allMessages,
        count: allMessages.length 
      });
    } catch (error: any) {
      console.error('Error checking messages:', error);
      res.status(500).json({ 
        message: "Failed to check messages", 
        error: error.message 
      });
    }
  });

  // Get specific email content
  app.get("/api/temp-email/:emailAddress/messages/:messageId", async (req, res) => {
    try {
      const { emailAddress, messageId } = req.params;
      const tempEmail = await storage.getTempEmail(emailAddress);
      
      if (!tempEmail) {
        return res.status(404).json({ message: "Email address not found" });
      }

      const messages = await storage.getEmailMessages(tempEmail.id);
      const message = messages.find(m => m.mailId === messageId);

      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }

      // Try to get full message content from Guerrilla Mail API
      try {
        const data = await callGuerrillaAPI({
          f: 'fetch_email',
          email_id: messageId,
          ip: '127.0.0.1',
          agent: 'TempMailPro',
          sid_token: tempEmail.sidToken
        });

        res.json({
          ...message,
          body: data.mail_body || message.body,
          htmlBody: data.mail_body || null
        });
      } catch (apiError) {
        // Return stored message if API fails
        res.json(message);
      }
    } catch (error: any) {
      console.error('Error fetching message:', error);
      res.status(500).json({ 
        message: "Failed to fetch message", 
        error: error.message 
      });
    }
  });

  // Extend email timer
  app.post("/api/temp-email/:emailAddress/extend", async (req, res) => {
    try {
      const { emailAddress } = req.params;
      const tempEmail = await storage.getTempEmail(emailAddress);
      
      if (!tempEmail) {
        return res.status(404).json({ message: "Email address not found" });
      }

      // Extend by 10 minutes
      const newExpiresAt = new Date(tempEmail.expiresAt.getTime() + 10 * 60 * 1000);
      
      // Update in storage (simplified - in real implementation you'd update the record)
      tempEmail.expiresAt = newExpiresAt;

      res.json({ 
        message: "Timer extended successfully",
        expiresAt: newExpiresAt 
      });
    } catch (error: any) {
      console.error('Error extending timer:', error);
      res.status(500).json({ 
        message: "Failed to extend timer", 
        error: error.message 
      });
    }
  });

  // AirTM payment route for premium upgrade
  app.post("/api/create-purchase", async (req, res) => {
    try {
      const { amount = 4.99 } = req.body;
      
      // Generate unique purchase ID
      const purchaseId = `tempmail_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Create AirTM payment request
      // AirTM uses a simple redirect-based approach for payments
      const airtmPaymentUrl = new URL('https://pay.airtm.com/checkout');
      airtmPaymentUrl.searchParams.set('merchant_id', 'tempmail_pro'); // Your AirTM merchant ID
      airtmPaymentUrl.searchParams.set('amount', amount.toString());
      airtmPaymentUrl.searchParams.set('currency', 'USD');
      airtmPaymentUrl.searchParams.set('description', 'TempMail Pro Premium Upgrade - 1 Month');
      airtmPaymentUrl.searchParams.set('reference', purchaseId);
      airtmPaymentUrl.searchParams.set('success_url', `${req.headers.origin || 'http://localhost:5000'}/checkout/success`);
      airtmPaymentUrl.searchParams.set('cancel_url', `${req.headers.origin || 'http://localhost:5000'}/checkout/cancel`);
      airtmPaymentUrl.searchParams.set('webhook_url', `${req.headers.origin || 'http://localhost:5000'}/api/webhook/airtm`);

      res.json({ 
        purchaseId: purchaseId,
        redirectUrl: airtmPaymentUrl.toString(),
        amount: amount.toString(),
        status: "created"
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error creating purchase: " + error.message 
      });
    }
  });

  // AirTM webhook for payment confirmation
  app.post("/api/webhook/airtm", async (req, res) => {
    try {
      const { reference, status, amount } = req.body;
      
      // Verify payment status
      if (status === 'completed') {
        // Here you would update user's premium status in your database
        console.log(`Payment completed for reference: ${reference}, amount: ${amount}`);
        
        // In a real app, you'd:
        // 1. Verify the webhook signature
        // 2. Update user's subscription status
        // 3. Send confirmation email
      }
      
      res.status(200).json({ received: true });
    } catch (error: any) {
      console.error('Webhook error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
