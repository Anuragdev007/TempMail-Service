# TempMail Pro - Temporary Email Service

## Overview

TempMail Pro is a modern full-stack web application that provides anonymous temporary email addresses for users. The application allows users to generate disposable email addresses, receive emails, and manage their temporary inbox without requiring registration. It features a freemium model with premium subscriptions through Stripe integration.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized builds
- **Payment Processing**: Stripe integration for premium subscriptions

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple
- **External API**: Guerrilla Mail API for temporary email generation

### Monorepo Structure
The project follows a monorepo structure with clear separation of concerns:
- `client/` - React frontend application
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript types and database schema
- Root level configuration files for build tools and database

## Key Components

### Database Schema (`shared/schema.ts`)
- **users**: User accounts with Stripe integration fields
- **tempEmails**: Temporary email addresses with expiration tracking
- **emailMessages**: Received email messages linked to temporary addresses

### Frontend Components
- **EmailGenerator**: Generates and manages temporary email addresses
- **InboxPanel**: Displays received emails with real-time polling
- **EmailModal**: Full email viewing interface
- **Sidebar**: Premium upgrade prompts and advertisements

### Backend Services
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **Guerrilla Mail Integration**: API wrapper for external email service
- **Stripe Integration**: Payment processing and subscription management

## Data Flow

1. **Email Generation**: User requests temporary email → Backend calls Guerrilla Mail API → Stores email data in database → Returns email address to frontend
2. **Email Receiving**: Frontend polls backend every 5 seconds → Backend queries Guerrilla Mail API for new messages → Stores messages in database → Returns to frontend
3. **Premium Upgrade**: User initiates checkout → Stripe payment processing → Backend updates user subscription status
4. **Email Expiration**: Emails expire after 10 minutes → Auto-generation of new email addresses

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **stripe**: Payment processing
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI components foundation

### Development Tools
- **TypeScript**: Type safety across the stack
- **Vite**: Frontend build tool with HMR
- **esbuild**: Backend bundling for production
- **Tailwind CSS**: Utility-first styling

### External APIs
- **Guerrilla Mail API**: Temporary email generation and message retrieval
- **Stripe API**: Payment processing and subscription management

## Deployment Strategy

### Development
- Frontend served through Vite dev server with HMR
- Backend runs with tsx for TypeScript execution
- Database migrations handled through Drizzle Kit
- Environment variables for API keys and database URL

### Production Build
- Frontend built to static assets via Vite
- Backend bundled with esbuild for Node.js deployment
- Single process serving both API and static files
- PostgreSQL database with connection pooling

### Configuration Requirements
- `DATABASE_URL`: PostgreSQL connection string
- `STRIPE_SECRET_KEY`: Stripe API secret key
- `VITE_STRIPE_PUBLIC_KEY`: Stripe publishable key (frontend)

## Changelog
- July 04, 2025. Initial setup with Stripe integration
- July 04, 2025. Replaced Stripe with AirTM payment integration for Indian market compatibility
- July 04, 2025. Implemented dark theme design with clean, modern UI using purple gradient themes
- July 04, 2025. Integrated Guerrilla Mail API for real-time temporary email generation and inbox functionality
- January 04, 2025. Implemented real Replit OpenID Connect authentication system
- January 04, 2025. Created Contact Support, Privacy Policy, and About Us pages for Google AdSense approval
- January 04, 2025. Added multiple Google AdSense ad spaces throughout the website (728x90 banners, 300x250 rectangles, 300x600 skyscrapers)
- January 04, 2025. Made premium features seamless with one-click upgrade for authenticated users
- January 04, 2025. Enhanced SEO with proper meta tags, structured content, and footer links
- January 04, 2025. Updated database schema to support real user authentication with PostgreSQL

## Recent Features Added
### Authentication System
- Real Replit OpenID Connect integration (not dummy)
- Database-backed user storage with PostgreSQL
- Seamless premium upgrade flow for authenticated users
- User profile display with avatar and premium status badges

### Google AdSense Optimization
- Multiple ad spaces strategically placed throughout the website
- SEO-optimized content with proper meta descriptions and keywords
- Additional pages (About Us, Contact Support, Privacy Policy) required for AdSense approval
- Improved website structure with footer navigation and content hierarchy

### Premium Features
- One-click premium upgrade for authenticated users (no payment required)
- 24-hour email retention vs 10-minute standard emails
- Premium user interface with crown badges and special styling
- Database tracking of premium status and expiration dates

### User Experience Improvements
- Authentication-aware navigation with user dropdown menus
- Mobile-responsive design with hamburger menu
- Enhanced dark theme with proper contrast and accessibility
- Real-time email notifications (toast + browser notifications)

## User Preferences

Preferred communication style: Simple, everyday language.
Payment preference: AirTM instead of Stripe for Indian market compatibility.
Authentication: Real authentication system using Replit OpenID Connect.
Monetization: Google AdSense approval focus with multiple ad spaces.
Premium features: Seamless one-click upgrade for authenticated users.